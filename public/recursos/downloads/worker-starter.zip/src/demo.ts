import { runWorker } from './worker.ts'
const attempts = new Map<string, number>()
const result = await runWorker([{ id: 'one', payload: 100 }, { id: 'one', payload: 100 }, { id: 'bad', payload: 0 }], async message => {
  const count = (attempts.get(message.id) ?? 0) + 1; attempts.set(message.id, count)
  if (message.id === 'bad' || count === 1) throw new Error('synthetic failure')
  console.log('Completed', message.id)
})
console.log(JSON.stringify(result, null, 2))
