export interface Message<T> { id: string; payload: T }
export async function runWorker<T>(messages: Message<T>[], handle: (message: Message<T>) => Promise<void>, maxAttempts = 3) {
  if (!Number.isInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 100) throw new Error('maxAttempts must be 1..100')
  const completed = new Set<string>()
  const dead: { message: Message<T>; attempts: number }[] = []
  for (const message of messages) {
    if (completed.has(message.id) || dead.some(entry => entry.message.id === message.id)) continue
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try { await handle(message); completed.add(message.id); break }
      catch { if (attempt === maxAttempts) dead.push({ message, attempts: attempt }) }
    }
  }
  return { completed: [...completed], dead }
}
