# Worker com tentativas limitadas

Node.js 22+. Execute npm install, npm test, npm run typecheck e npm start.

Worker sequencial em TypeScript com retries e deduplicação local à execução. Falhas esgotadas retornam na lista dead. O exemplo usa apenas dados fictícios. Consulte README.md para o mapa dos arquivos.

É um exemplo didático sem broker durável, backoff, transações, controle de concorrência ou deduplicação entre processos. O handler precisa ser idempotente: uma falha depois de um efeito pode repeti-lo. Antes de produção, persista IDs na mesma transação da operação de negócio e defina desligamento e reprocessamento.

MIT. https://lagrotti.dev/recursos/templates/worker
