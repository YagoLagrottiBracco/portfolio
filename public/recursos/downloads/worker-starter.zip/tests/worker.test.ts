import test from 'node:test'
import assert from 'node:assert/strict'
import { runWorker } from '../src/worker.ts'
test('retries transient failures and deduplicates completed IDs', async () => {
 let attempts = 0
 const r = await runWorker([{id:'a', payload:1}, {id:'a', payload:1}], async () => { if (++attempts < 2) throw new Error('retry') })
 assert.equal(attempts, 2); assert.deepEqual(r.completed, ['a']); assert.equal(r.dead.length, 0)
})
test('permanent failures stop at three attempts and enter dead letters', async () => {
 let attempts = 0
 const r = await runWorker([{id:'a', payload:1}], async () => { attempts++; throw new Error('bad') })
 assert.equal(attempts, 3); assert.equal(r.dead[0].attempts, 3); assert.equal(r.completed.length, 0)
})
test('rejects invalid retry bounds', async () => {
 await assert.rejects(() => runWorker([], async () => {}, 0), /maxAttempts/)
})
