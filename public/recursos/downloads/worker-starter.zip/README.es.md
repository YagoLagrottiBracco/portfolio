# Worker con intentos limitados

Node.js 22+. Ejecuta npm install, npm test, npm run typecheck y npm start.

Worker secuencial TypeScript con reintentos y deduplicación local a una ejecución. Los fallos agotados van a dead. El ejemplo usa datos ficticios. README.md explica cada archivo.

Ejemplo didáctico sin broker duradero, backoff, transacciones, control de concurrencia ni deduplicación entre procesos. El handler debe ser idempotente: un fallo tras un efecto puede repetirlo. Antes de producción, guarda IDs en la misma transacción de negocio y define cierre y reprocesamiento.

MIT. https://lagrotti.dev/es/recursos/templates/worker
