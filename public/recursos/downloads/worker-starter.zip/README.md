# Bounded worker starter

Node.js 22+. Run: npm install, npm test, npm run typecheck, npm start.

A small sequential TypeScript worker. Duplicate completed IDs within one run are skipped. A handler can fail up to three attempts; exhausted messages enter the returned dead-letter list.

Files: src/worker.ts (logic), src/demo.ts (synthetic example), tests/worker.test.ts (behavior), .github/workflows/ci.yml (CI).

This educational starter has no durable broker, backoff, transactions, concurrency control or cross-process deduplication. Handlers must be idempotent: a failure after a side effect can repeat that effect. Persist IDs transactionally with the business operation before using this pattern in production. Avoid logging secrets and add shutdown/replay policy for your environment.

MIT. Yago Lagrotti Bracco — https://lagrotti.dev/recursos/templates/worker
